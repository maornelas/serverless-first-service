
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'marcoornelas',
  applicationName: 'myapp',
  appUid: 'KhFHCxJCc8ytYpy6GK',
  orgUid: 'a17ea510-0092-4e03-a147-5592934f8039',
  deploymentUid: 'b505b1bf-6833-4775-945d-b543f7777750',
  serviceName: 'user-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'user-service-dev-loginUser', timeout: 6 };

try {
  const userHandler = require('./src/functions/login.js');
  module.exports.handler = serverlessSDK.handler(userHandler.login, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}