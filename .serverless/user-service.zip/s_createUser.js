
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'marcoornelas',
  applicationName: 'myapp',
  appUid: 'KhFHCxJCc8ytYpy6GK',
  orgUid: 'a17ea510-0092-4e03-a147-5592934f8039',
  deploymentUid: '29f58471-b2c7-4260-b8aa-a8d986bfb90f',
  serviceName: 'user-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'user-service-dev-createUser', timeout: 6 };

try {
  const userHandler = require('./src/functions/createUser.js');
  module.exports.handler = serverlessSDK.handler(userHandler.createUser, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}